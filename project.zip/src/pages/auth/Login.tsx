import React from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '@/hooks/useAuth'

const Login: React.FC = () => {
  const [email, setEmail] = React.useState('')
  const [password, setPassword] = React.useState('')
  const { signIn } = useAuth()
  const navigate = useNavigate()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const { data, error } = await signIn(email, password)
    
    if (error) {
      console.error('Login error', error)
      // Handle login error (show message to user)
    } else {
      navigate('/dashboard')
    }
  }

  return (
    <div className="max-w-md mx-auto">
      <form onSubmit={handleSubmit} className="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
        <input 
          type="email" 
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Email"
          required 
          className="mb-4 w-full px-3 py-2 border rounded"
        />
        <input 
          type="password" 
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Password"
          required 
          className="mb-4 w-full px-3 py-2 border rounded"
        />
        <button 
          type="submit" 
          className="w-full bg-primary text-white py-2 rounded"
        >
          Login
        </button>
      </form>
    </div>
  )
}

export default Login