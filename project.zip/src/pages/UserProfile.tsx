import React, { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '@/hooks/useAuth'
import { getUserProfile } from '@/lib/supabase/database'

const UserProfile: React.FC = () => {
  const { user } = useAuth()
  const [profile, setProfile] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const navigate = useNavigate()

  useEffect(() => {
    const fetchProfile = async () => {
      if (!user) {
        navigate('/login')
        return
      }

      try {
        const profileData = await getUserProfile(user.id)
        setProfile(profileData)
        setLoading(false)
      } catch (error) {
        console.error('Failed to fetch profile', error)
        navigate('/login')
      }
    }

    fetchProfile()
  }, [user, navigate])

  if (loading) {
    return <div>Loading...</div>
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-white shadow-md rounded-lg p-6">
        <h1 className="text-2xl font-bold mb-4">User Profile</h1>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <h2 className="text-xl font-semibold">Personal Information</h2>
            <p>Username: {profile?.username}</p>
            <p>Email: {user?.email}</p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default UserProfile