import React, { useState, useEffect } from 'react'
import { useAuth } from '@/hooks/useAuth'
import { fetchSwapRequests, updateSwapRequest } from '@/lib/supabase/database'

const SwapRequests: React.FC = () => {
  const { user } = useAuth()
  const [swapRequests, setSwapRequests] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const loadSwapRequests = async () => {
      if (user) {
        try {
          const requests = await fetchSwapRequests(user.id)
          setSwapRequests(requests)
          setLoading(false)
        } catch (error) {
          console.error('Failed to fetch swap requests', error)
        }
      }
    }

    loadSwapRequests()
  }, [user])

  const handleSwapAction = async (requestId: string, status: 'accepted' | 'rejected') => {
    try {
      await updateSwapRequest(requestId, status)
      // Refresh swap requests
      const updatedRequests = await fetchSwapRequests(user.id)
      setSwapRequests(updatedRequests)
    } catch (error) {
      console.error('Failed to update swap request', error)
    }
  }

  if (loading) return <div>Loading swap requests...</div>

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">Swap Requests</h1>
      {swapRequests.map((request) => (
        <div key={request.id} className="bg-white shadow-md rounded-lg p-4 mb-4">
          {/* Swap request details */}
          <div className="flex justify-between">
            <button 
              onClick={() => handleSwapAction(request.id, 'accepted')}
              className="bg-green-500 text-white px-4 py-2 rounded"
            >
              Accept
            </button>
            <button 
              onClick={() => handleSwapAction(request.id, 'rejected')}
              className="bg-red-500 text-white px-4 py-2 rounded"
            >
              Reject
            </button>
          </div>
        </div>
      ))}
    </div>
  )
}

export default SwapRequests