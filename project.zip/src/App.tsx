import React from 'react'
import { Routes, Route } from 'react-router-dom'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import Home from '@/pages/Home'
import Login from '@/pages/auth/Login'
import Register from '@/pages/auth/Register'
import Dashboard from '@/pages/Dashboard'
import ItemBrowser from '@/pages/items/ItemBrowser'
import ItemDetail from '@/pages/items/ItemDetail'
import AddItem from '@/pages/items/AddItem'
import UserProfile from '@/pages/UserProfile'  // New import

const App: React.FC = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <Navbar />
      <main className="flex-grow container mx-auto px-4 py-8">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/items" element={<ItemBrowser />} />
          <Route path="/items/:id" element={<ItemDetail />} />
          <Route path="/add-item" element={<AddItem />} />
          <Route path="/profile" element={<UserProfile />} />  {/* New route */}
        </Routes>
      </main>
      <Footer />
    </div>
  )
}

export default App