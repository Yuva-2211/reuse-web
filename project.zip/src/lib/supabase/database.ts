import { supabase } from './client'

// User-related database operations
export const getUserProfile = async (userId: string) => {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single()

  if (error) throw error
  return data
}

// Item-related database operations
export const fetchItems = async (filters = {}) => {
  let query = supabase.from('items').select('*')

  // Apply filters if provided
  Object.entries(filters).forEach(([key, value]) => {
    query = query.eq(key, value)
  })

  const { data, error } = await query

  if (error) throw error
  return data
}

export const addItem = async (itemData: any) => {
  const { data, error } = await supabase
    .from('items')
    .insert(itemData)
    .select()

  if (error) throw error
  return data[0]
}