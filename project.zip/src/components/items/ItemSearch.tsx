import React, { useState } from 'react'
import { MagnifyingGlassIcon } from '@heroicons/react/24/solid'

interface SearchFilters {
  category?: string
  size?: string
  condition?: string
}

interface ItemSearchProps {
  onSearch: (filters: SearchFilters) => void
}

const ItemSearch: React.FC<ItemSearchProps> = ({ onSearch }) => {
  const [filters, setFilters] = useState<SearchFilters>({})

  const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const { name, value } = e.target
    const newFilters = { ...filters, [name]: value }
    setFilters(newFilters)
    onSearch(newFilters)
  }

  return (
    <div className="mb-6 bg-white shadow-md rounded-lg p-4">
      <div className="flex items-center mb-4">
        <MagnifyingGlassIcon className="h-6 w-6 text-primary mr-2" />
        <input 
          type="text" 
          placeholder="Search items..." 
          className="w-full px-3 py-2 border rounded-md"
        />
      </div>
      <div className="grid md:grid-cols-3 gap-4">
        <select 
          name="category" 
          onChange={handleFilterChange} 
          className="px-3 py-2 border rounded-md"
        >
          <option value="">All Categories</option>
          <option value="tops">Tops</option>
          <option value="bottoms">Bottoms</option>
          <option value="dresses">Dresses</option>
          <option value="accessories">Accessories</option>
        </select>
        <select 
          name="size" 
          onChange={handleFilterChange} 
          className="px-3 py-2 border rounded-md"
        >
          <option value="">All Sizes</option>
          <option value="xs">XS</option>
          <option value="s">S</option>
          <option value="m">M</option>
          <option value="l">L</option>
          <option value="xl">XL</option>
        </select>
        <select 
          name="condition" 
          onChange={handleFilterChange} 
          className="px-3 py-2 border rounded-md"
        >
          <option value="">All Conditions</option>
          <option value="new">New</option>
          <option value="like-new">Like New</option>
          <option value="good">Good</option>
          <option value="fair">Fair</option>
        </select>
      </div>
    </div>
  )
}

export default ItemSearch