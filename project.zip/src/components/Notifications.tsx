import React, { useState, useEffect } from 'react'
import { useAuth } from '@/hooks/useAuth'
import { fetchNotifications, markNotificationAsRead } from '@/lib/supabase/database'

const Notifications: React.FC = () => {
  const { user } = useAuth()
  const [notifications, setNotifications] = useState([])

  useEffect(() => {
    const loadNotifications = async () => {
      if (user) {
        const userNotifications = await fetchNotifications(user.id)
        setNotifications(userNotifications)
      }
    }

    loadNotifications()
  }, [user])

  const handleNotificationClick = async (notificationId: string) => {
    await markNotificationAsRead(notificationId)
    // Update local state or redirect
  }

  return (
    <div className="notifications-dropdown">
      {notifications.map(notification => (
        <div 
          key={notification.id} 
          onClick={() => handleNotificationClick(notification.id)}
          className="notification-item"
        >
          {notification.message}
        </div>
      ))}
    </div>
  )
}

export default Notifications