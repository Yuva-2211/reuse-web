from flask import Flask, jsonify
from flask_login import LoginManager
from flask_cors import CORS
from config import Config
from models import db, User
import routes

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    
    # Initialize extensions
    CORS(app)
    db.init_app(app)
    
    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    
    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))
    
    # Register Blueprints
    app.register_blueprint(routes.auth_bp, url_prefix='/api/auth')
    app.register_blueprint(routes.items_bp, url_prefix='/api/items')
    app.register_blueprint(routes.swap_bp, url_prefix='/api/swaps')
    
    # Error Handlers
    @app.errorhandler(404)
    def not_found(error):
        return jsonify({"error": "Not found"}), 404
    
    @app.errorhandler(500)
    def server_error(error):
        return jsonify({"error": "Internal server error"}), 500
    
    @app.before_first_request
    def create_tables():
        db.create_all()
    
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)