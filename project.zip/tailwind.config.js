import { fontFamily } from 'tailwindcss/defaultTheme'

export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#2D5A27',
          light: '#3E7A39',
          dark: '#1D3D19'
        },
        secondary: {
          DEFAULT: '#F5F5DC',
          light: '#F9F9E0',
          dark: '#E0E0C0'
        },
        accent: {
          DEFAULT: '#E07A5F',
          light: '#E89A7E',
          dark: '#C05A3F'
        },
        neutral: {
          DEFAULT: '#F8F9FA',
          light: '#FFFFFF',
          dark: '#E0E0E0'
        }
      },
      fontFamily: {
        sans: ['Roboto', ...fontFamily.sans],
      },
      borderRadius: {
        'lg': '0.75rem',
        'xl': '1rem'
      },
      boxShadow: {
        'soft': '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
        'medium': '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)'
      }
    },
  },
  plugins: [],
}