# ReWear - Sustainable Fashion Exchange Platform

## 🌿 Project Overview

ReWear is an innovative web application designed to promote sustainable fashion by facilitating clothing and accessory exchanges between users. The platform enables individuals to swap their pre-loved items, reducing fashion waste and promoting a circular economy.

### 🌟 Key Features

- User Authentication & Profiles
- Item Listing and Browsing
- Swap Requests and Management
- Points-based Exchange System
- Sustainable Fashion Marketplace

## 🚀 Technology Stack

### Frontend
- React
- TypeScript
- Vite
- Tailwind CSS
- React Router
- Supabase Authentication

### Backend
- Flask
- SQLAlchemy
- PostgreSQL
- Supabase

## 🔧 Prerequisites

- Python 3.11+
- Node.js 18+
- npm or yarn
- Supabase Account

## 🛠️ Local Development Setup

### Backend Setup

1. Clone the repository