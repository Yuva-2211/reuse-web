from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from models import db, User, Item, Swap, UserSchema, ItemSchema, SwapSchema
from werkzeug.utils import secure_filename
import os

# Authentication Blueprint
auth_bp = Blueprint('auth', __name__)
items_bp = Blueprint('items', __name__)
swap_bp = Blueprint('swap', __name__)

user_schema = UserSchema()
users_schema = UserSchema(many=True)
item_schema = ItemSchema()
items_schema = ItemSchema(many=True)
swap_schema = SwapSchema()
swaps_schema = SwapSchema(many=True)

@auth_bp.route('/signup', methods=['POST'])
def signup():
    data = request.get_json()
    username = data.get('username')
    email = data.get('email')
    password = data.get('password')
    
    if User.query.filter_by(email=email).first():
        return jsonify({"error": "Email already registered"}), 400
    
    new_user = User(username=username, email=email)
    new_user.set_password(password)
    
    db.session.add(new_user)
    db.session.commit()
    
    return jsonify(user_schema.dump(new_user)), 201

@items_bp.route('/add', methods=['POST'])
@login_required
def add_item():
    data = request.form
    file = request.files.get('image')
    
    if file:
        filename = secure_filename(file.filename)
        file.save(os.path.join(current_app.config['UPLOAD_FOLDER'], filename))
    
    new_item = Item(
        title=data.get('title'),
        description=data.get('description'),
        category=data.get('category'),
        size=data.get('size'),
        condition=data.get('condition'),
        user_id=current_user.id,
        image_path=filename if file else None
    )
    
    db.session.add(new_item)
    db.session.commit()
    
    return jsonify(item_schema.dump(new_item)), 201

@swap_bp.route('/request', methods=['POST'])
@login_required
def create_swap_request():
    data = request.get_json()
    item_id = data.get('item_id')
    
    item = Item.query.get(item_id)
    if not item or item.status != 'Available':
        return jsonify({"error": "Item not available for swap"}), 400
    
    if not current_user.can_swap():
        return jsonify({"error": "Insufficient points for swap"}), 403
    
    swap = Swap(
        requester_id=current_user.id,
        owner_id=item.user_id,
        item_id=item_id
    )
    
    db.session.add(swap)
    db.session.commit()
    
    return jsonify(swap_schema.dump(swap)), 201